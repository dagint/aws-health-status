import boto3
import json
import decimal
from botocore.vendored import requests
import os
from datetime import datetime
from dateutil import parser
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError

def diff_dates(strDate1, strDate2):
    intSecs = float(strDate2)-float(strDate1)
    return intSecs

def update_ddb(objTable, strArn, strUpdate, now, intSeconds):
    response = objTable.put_item(
      Item ={
        'arn' : strArn,
        'lastUpdatedTime' : strUpdate,
        'added' : now,
        'ttl' : int(now) + int(intSeconds) + 3600
      }
    )

def get_healthMessage(awshealth, event, strArn, awsRegion):
    event_details = awshealth.describe_event_details (
      eventArns=[
        strArn,
      ]
    )
    json_event_details = json.dumps(event_details, cls=DatetimeEncoder)
    parsed_event_details = json.loads (json_event_details)
    healthMessage = (parsed_event_details['successfulSet'][0]['eventDescription']['latestDescription'])#print parsed_event_deta
    healthMessage = '\n' + healthMessage + '\n\nService: ' + str(event['service']) + '\nRegion: ' + str(event['region']) + '\nStatus: ' + str(event['statusCode'])
    phdURL = 'https://phd.aws.amazon.com/phd/home?region=' + awsRegion + '#/event-log?eventID=' + strArn + '&eventTab=details&layout=vertical'
    healthMessage = healthMessage + '\n\nPHD URL: ' + phdURL
    return healthMessage

def send_sns(healthMessage, eventName, SNSTopic, enableSNS):
    if enableSNS: 
      snsClient = boto3.client('sns')
      snsPub = snsClient.publish(
        Message = str(healthMessage),
        Subject = str(eventName),
        TopicArn = SNSTopic
      )

def get_healthSubject(event):
    eventTypeCode = str(event['eventTypeCode'])
    service = str(event['service'])
    region =  str(event['region'])
    eventName = eventTypeCode + ' - ' + service + ' - ' + region
    return eventName

class DatetimeEncoder(json.JSONEncoder):
    def default(self, obj):
        try:
            return super(DatetimeEncoder, obj).default(obj)
        except TypeError:
            return str(obj)

def lambda_handler(event, context):
    # TODO implement
    # ignore events past the x number of seconds 14400 = 4 hours
    intSeconds = os.environ['ttl']  #14400
    #example format of regions= 'us-east-1','us-east-2','global'
    dictRegions = os.environ['regions']
    enableSNS = os.environ['enableSNS']  
    SNSTopic = os.environ['SNSTopic']
    ddbTable = os.environ['ddbTable']
    awsRegion = os.environ['AWS_DEFAULT_REGION']
    
    if dictRegions != "":
        #dictRegions = str("[" + dictRegions + "]")
        dictRegions = dictRegions.replace("'","")
        dictRegions = list(dictRegions.split(",")) 
        print (dictRegions)
    
    
    #used to determine if event is related to something in SHD
    strSuffix = "_OPERATIONAL_ISSUE"
    #set standard date time format used throughout
    strDTMFormat2 = "%Y-%m-%d %H:%M:%S"
    strDTMFormat = '%s'
        
    # creates health object as client.  AWS health only has a us-east-1 endpoint currently
    awshealth = boto3.client('health', region_name='us-east-1')

    dynamodb = boto3.resource("dynamodb")

    SHDIssuesTable = dynamodb.Table(ddbTable)

    strFilter = {'eventTypeCategories': ['issue',]}

    if dictRegions != "":
    	strFilter = {
	    	'eventTypeCategories': [
		    	'issue',
		    ],
    		'regions': 
	    		dictRegions
    	}

    response = awshealth.describe_events (
        filter=
            strFilter
        ,
    )

    json_pre = json.dumps(response, cls=DatetimeEncoder)
    json_events = json.loads (json_pre)

    if (json_events['ResponseMetadata']['HTTPStatusCode']) == 200:
        events = json_events.get('events')
        for event in events :
            #print ("events for")
            strEventTypeCode = event['eventTypeCode']
            if strEventTypeCode.endswith(strSuffix):
                strArn = (event['arn'])
                strUpdate = parser.parse((event['lastUpdatedTime']))
                #strUpdate = parser.parse(strUpdate)
                strUpdate = strUpdate.strftime(strDTMFormat)
                now = datetime.strftime(datetime.now(),strDTMFormat)
                if diff_dates(strUpdate, now) < int(intSeconds):
                    try:
                        response = SHDIssuesTable.get_item(
                            Key = {
                                'arn' : strArn
                            }
                    )
                    except ClientError as e:
                        print(e.response['Error']['Message'])
                    else:
                        isItemResponse = response.get('Item')
                        if isItemResponse == None:
                            print (datetime.now().strftime(strDTMFormat2)+": record not found")
                            update_ddb(SHDIssuesTable, strArn, strUpdate, now, intSeconds)
                            healthMessage = get_healthMessage(awshealth, event, strArn, awsRegion)
                            eventName = get_healthSubject(event)
                            print ("eventName: ", eventName)
                            print ("healthMessage: ",healthMessage)
                            if enableSNS:
                                send_sns(healthMessage, eventName, SNSTopic, enableSNS)
                        else:
                            item = response['Item']
                            if item['lastUpdatedTime'] != strUpdate:
                              print (datetime.now().strftime(strDTMFormat2)+": last Update is different")
                              update_ddb(SHDIssuesTable, strArn, strUpdate, now, intSeconds)
                              healthMessage = get_healthMessage(awshealth, event, strArn, awsRegion)
                              eventName = get_healthSubject(event)
                              print ("eventName: ", eventName)
                              print ("healthMessage: ",healthMessage)
                              if enableSNS:
                                send_sns(healthMessage, eventName, SNSTopic, enableSNS)
    else:
         return {
        'statusCode': 500,
        'body': json.dumps(str(datetime.now().strftime(strDTMFormat2))+"- API call was not successful: "+str((json_events['ResponseMetadata']['HTTPStatusCode'])))
        }
    return {
        'statusCode': 200,
        'body': json.dumps(str(datetime.now().strftime(strDTMFormat2))+"- API call was successful: "+str((json_events['ResponseMetadata']['HTTPStatusCode'])))
    }
